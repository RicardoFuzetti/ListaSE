public class Main {

    public static void main(String[] args) {

        ListaSE lista1 = new ListaSE();
        ListaSE lista2 = new ListaSE();
        OperacoesListaOrdenada op = new OperacoesListaOrdenada();

        lista1.insereOrdenado(2);
        lista1.insereOrdenado(3);
        lista1.insereOrdenado(60);
        lista1.insereOrdenado(9);

        lista2.insereOrdenado(2);
        lista2.insereOrdenado(3);
        lista2.insereOrdenado(6);
        lista2.insereOrdenado(7);

        System.out.println("A proximidade e de: " + op.Cos(lista1, lista2));
        ListaSE lista3 = op.intersecao(lista1, lista2);
        System.out.println("-----------------");
        System.out.println("Imprimindo intercesao: ");
        lista3.imprime();
        lista3.retiraUltimo();
        System.out.println("----------");
        System.out.println("Retirando ultimo No da lista: ");
        lista3.imprime();
        lista3.insereUltimo(6);
        lista3.retiraPrimeiro();
        System.out.println("--------------");
        System.out.println("Retirando primeiro No da lista: ");
        lista3.imprime();
        lista3.inserePrimeiro(2);
        lista3.retiraDepois(lista3.primeiro);
        System.out.println("-----------------");
        System.out.println("Retirando depois de um No: ");
        lista3.imprime();
        System.out.println("------------------------------");
        System.out.println("Verificando ultimo elemento da lista: ");
        System.out.println(lista3.ultimoElemento());
    }
}
